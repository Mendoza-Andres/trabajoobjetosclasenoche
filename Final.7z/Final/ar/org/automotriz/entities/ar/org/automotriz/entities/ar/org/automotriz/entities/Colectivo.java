
package ar.org.automotriz.entities;

public final class Colectivo extends Vehiculo {
    public Colectivo(String marca, String modelo, String color, int precio, String radiomarca, String potencia) {
        super(marca, modelo, color, precio, radiomarca, potencia);

    }

    public Colectivo(String marca, String modelo, String color, int precio) {
        super(marca, modelo, color, precio);

    }

    public Colectivo(String marca, String modelo, String color) {
        super(marca, modelo, color);

    }

    public Colectivo(String marca, String modelo, String color, String radiomarca, String potencia) {
        super(marca, modelo, color, radiomarca, potencia);

    }

}
