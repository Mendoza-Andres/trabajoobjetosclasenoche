package ar.org.automotriz.test;

import ar.org.automotriz.entities.AutoClasico;
import ar.org.automotriz.entities.AutoNuevo;
import ar.org.automotriz.entities.Colectivo;

public class TestVehiculo {
  public static void main(String[] args) {
    System.out.println("Colectivo 1");
    Colectivo Colectivo1 = new Colectivo("Colectivo1Marca", "Colectivo1Modelo", "Colectivo1Color", 123);
    System.out.println(Colectivo1);
    Colectivo1.instalar("Colectivo1RadioMarca1", "Colectivo1Potencia1");
    System.out.println(Colectivo1);
    Colectivo1.modificar("Colectivo1RadioMarca2", "Colectivo1Potencia2");
    System.out.println(Colectivo1);

    System.out.println("AutoClasico 1");
    AutoClasico AutoClasico1 = new AutoClasico("AutoClasico1Marca", "AutoClasico1Modelo", "AutoClasico1Color", "AutoClasico1RadioMarca1", "AutoClasico1Potencia1");
    System.out.println(AutoClasico1);
    AutoClasico1.modificar("AutoClasico1RadioMarca2", "AutoClasico1Potencia2");
    System.out.println(AutoClasico1);

    System.out.println("AutoClasico 2");
    AutoClasico AutoClasico2 = new AutoClasico("AutoClasico2Marca", "AutoClasico2Modelo", "AutoClasico2Color");
    System.out.println(AutoClasico2);
    AutoClasico2.modificar("AutoClasico2RadioMarca", "AutoClasico2Potencia");
    System.out.println(AutoClasico2);

    System.out.println("AutoNuevo 1");
    AutoNuevo AutoNuevo1 = new AutoNuevo("AutoNuevo1Marca", "AutoNuevo1Modelo", "AutoNuevo1Color", 321, "AutoNuevo1RadioMarca1", "AutoNuevo1Potencia1");
    System.out.println(AutoNuevo1);
    AutoNuevo1.modificar("AutoNuevo1RadioMarca2", "AutoNuevo1Potencia2");
    System.out.println(AutoNuevo1);

    System.out.println("Colectivo 2");
    Colectivo Colectivo2 = new Colectivo("Colectivo2Marca", "Colectivo2Modelo", "Colectivo2Color", 456, "Colectivo2RadioMarca", "Colectivo2Potencia");
    System.out.println(Colectivo2);

    System.out.println("AutoClasico 3");
    AutoClasico AutoClasico3 = new AutoClasico("AutoClasico3Marca", "AutoClasico3Modelo", "AutoClasico3Color");
    System.out.println(AutoClasico3);

    System.out.println("AutoClasico 4");
    AutoClasico AutoClasico4 = new AutoClasico("AutoClasico4Marca", "AutoClasico4Modelo", "AutoClasico4Color", "AutoClasico4RadioMarca1", "AutoClasico4Potencia1");
    System.out.println(AutoClasico4);
    AutoClasico4.instalar("AutoClasico4RadioMarca2", "AutoClasico4Potencia2");
    System.out.println(AutoClasico4);
  }
}
