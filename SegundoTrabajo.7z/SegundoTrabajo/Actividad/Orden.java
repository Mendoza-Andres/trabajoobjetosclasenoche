import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;


public class Orden {
    
    public static void main(String[] args) {
        List<Consecionario>list=new ArrayList<>();
     list.add(new Consecionario("peugeot", "206", 4, 200000.00)); 
     list.add(new Consecionario("honda", "titan", "125c", 60000.00));
    list.add(new Consecionario("peugeot", "208", 5, 250000.00));
    list.add(new Consecionario("yamaha", "YBR", "160c", 80500.50));
     list.stream().forEach(System.out::println);
    }
}
