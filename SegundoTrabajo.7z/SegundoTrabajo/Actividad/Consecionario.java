import java.text.DecimalFormat;

public class Consecionario implements Comparable<Consecionario> {

    private String marca;
    private String modelo;
    private int nropuertas;
    private String cilindrada;
    private double precio;

    public Consecionario(String marca, String modelo, int nropuertas, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.nropuertas = nropuertas;
        this.precio = precio;
    }

    public Consecionario(String marca, String modelo, String cilindrada, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.cilindrada = cilindrada;
        this.precio = precio;
    }

    @Override
    public int compareTo(Consecionario para) {
        DecimalFormat df = new DecimalFormat("000");
        String thisConsecionario = this.getMarca() + ", " + this.getModelo() + ", " + this.getNropuertas() + ", "
                + this.getCilindrada() + ", " + df.format(this.getPrecio());
        String paraConsecionario = para.getMarca() + ", " + para.getModelo() + ", " + para.getNropuertas() + ", "
                + para.getCilindrada() + ", " + df.format(para.getPrecio());

        return thisConsecionario.compareTo(paraConsecionario);
    }

    @Override
    public String toString() {
        return "Consecionario [marca=" + marca + ", modelo=" + modelo + ", nropuertas=" + nropuertas + ", cilindrada="
                + cilindrada + ", precio=" + precio + "]";
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getNropuertas() {
        return nropuertas;
    }

    public String getCilindrada() {
        return cilindrada;
    }

    public double getPrecio() {
        return precio;
    }

   

}
